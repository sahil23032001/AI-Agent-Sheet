/**
 * Local test harness — runs Code.gs outside Apps Script with stubbed globals,
 * so the prompt builder, parser and cell-write logic can be verified.
 *
 *   node test/harness.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'Code.gs'), 'utf8');

// ---- fake sheet -------------------------------------------------------
const GRID = [
  ['Customer', 'Issue', 'Summary'],
  ['Acme Ltd', 'Billing', 'Invoice 4471 was charged twice in March.'],
  ['Nordwind', 'Shipping', 'Pallet arrived with two crates crushed.'],
  ['初鹿 KK', 'Billing', 'VAT number missing from the January invoice.'],
  ['Vetrix', 'Billing', 'Customer reported that the'],   // active row (4-index 3 -> row 5)
  ['Halden', 'Support', 'Login loop on SSO after password reset.'],
];
let ACTIVE = { row: 5, col: 3 };
let SELECTION = null;   // {row, col, rows, cols} when more than one cell is selected
const writes = [];

function cellVal(r, c) {
  const row = GRID[r - 1] || [];
  return row[c - 1] === undefined ? '' : row[c - 1];
}

function makeRange(row, col, nRows, nCols) {
  return {
    getRow: () => row,
    getColumn: () => col,
    getNumRows: () => nRows,
    getNumColumns: () => nCols,
    getLastRow: () => row + nRows - 1,
    getLastColumn: () => col + nCols - 1,
    getA1Notation: () => (nRows > 1 || nCols > 1)
      ? colLetter(col) + row + ':' + colLetter(col + nCols - 1) + (row + nRows - 1)
      : colLetter(col) + row,
    getDisplayValue: () => String(cellVal(row, col)),
    getDisplayValues: () => {
      const out = [];
      for (let r = row; r < row + nRows; r++) {
        const line = [];
        for (let c = col; c < col + nCols; c++) line.push(String(cellVal(r, c)));
        out.push(line);
      }
      return out;
    },
    setValue: (v) => { writes.push({ a1: colLetter(col) + row, v }); GRID[row - 1][col - 1] = v; },
  };
}

function colLetter(n) {
  let s = '';
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = (n - m - 1) / 26; }
  return s;
}

function parseA1(a1) {
  const m = /^([A-Z]+)(\d+)$/.exec(a1);
  let col = 0;
  for (const ch of m[1]) col = col * 26 + (ch.charCodeAt(0) - 64);
  return { row: Number(m[2]), col };
}

const sheet = {
  getName: () => 'Tickets',
  getActiveCell: () => makeRange(ACTIVE.row, ACTIVE.col, 1, 1),
  getActiveRange: () => (SELECTION
    ? makeRange(SELECTION.row, SELECTION.col, SELECTION.rows, SELECTION.cols)
    : makeRange(ACTIVE.row, ACTIVE.col, 1, 1)),
  setActiveRange: (r) => { ACTIVE = { row: r.getRow(), col: r.getColumn() }; },
  getSheetId: () => 0,
  getLastRow: () => GRID.length,
  getLastColumn: () => Math.max(...GRID.map(r => r.length)),
  getRange: (...a) => {
    if (typeof a[0] === 'string') { const p = parseA1(a[0]); return makeRange(p.row, p.col, 1, 1); }
    return makeRange(a[0], a[1], a[2] === undefined ? 1 : a[2], a[3] === undefined ? 1 : a[3]);
  },
};

// ---- fake Apps Script services ---------------------------------------
const store = {};
let lastFetch = null;
let fetchResponse = () => ({
  code: 200,
  text: JSON.stringify({
    choices: [{ message: { content: '{"completions":["invoice total did not match the purchase order.","charge appeared twice on the same statement.","refund never reached their account."]}' } }],
  }),
});

const sandbox = {
  console,
  SpreadsheetApp: {
    getActiveSheet: () => sheet,
    getActiveSpreadsheet: () => ({
      getSheetByName: (n) => (n === 'Tickets' ? sheet : null),
      getActiveSheet: () => sheet,
      getSheets: () => [sheet],
    }),
    getUi: () => ({ createMenu: () => ({ addItem() { return this; }, addSeparator() { return this; }, addToUi() {} }) }),
    flush: () => {},
  },
  PropertiesService: {
    getUserProperties: () => ({
      getProperty: (k) => (k in store ? store[k] : null),
      setProperty: (k, v) => { store[k] = v; },
      deleteProperty: (k) => { delete store[k]; },
    }),
  },
  CacheService: { getUserCache: () => null },
  HtmlService: { createHtmlOutputFromFile: () => ({ setTitle: () => ({}) }) },
  Utilities: { sleep: () => {} },
  UrlFetchApp: {
    fetch: (url, opts) => {
      lastFetch = { url, opts, body: opts.payload ? JSON.parse(opts.payload) : null };
      const r = fetchResponse();
      return { getResponseCode: () => r.code, getContentText: () => r.text };
    },
  },
};
vm.createContext(sandbox);
vm.runInContext(src, sandbox, { filename: 'Code.gs' });

// ---- tests ------------------------------------------------------------
let pass = 0;
// Arrays created inside the vm context have a different Array prototype, so
// deepStrictEqual would fail on prototype identity alone. Normalise first.
function eq(actual, expected, msg) {
  assert.deepStrictEqual(JSON.parse(JSON.stringify(actual)), expected, msg);
}

function t(name, fn) {
  try { fn(); pass++; console.log('  ✔ ' + name); }
  catch (e) { console.error('  ✘ ' + name + '\n    ' + e.message); process.exitCode = 1; }
}

console.log('\nGroq Sheets Autocomplete — harness\n');

sandbox.saveApiKey('gsk_test_key');

console.log('context engine');
t('reads header, row facts and column neighbours for a partly typed cell', () => {
  const ctx = sandbox.getCellContext();
  assert.strictEqual(ctx.a1, 'C5');
  assert.strictEqual(ctx.header, 'Summary');
  assert.strictEqual(ctx.text, 'Customer reported that the');
  eq(ctx.rowPairs.map(p => p.header), ['Customer', 'Issue']);
  eq(ctx.rowPairs.map(p => p.value), ['Vetrix', 'Billing']);
  assert.strictEqual(ctx.neighbours.length, 4, 'four other filled Summary cells');
  assert.ok(ctx.neighbours.indexOf('Customer reported that the') === -1, 'active cell excluded');
});

t('never leaks the header row into the neighbour examples', () => {
  const ctx = sandbox.getCellContext();
  assert.ok(ctx.neighbours.indexOf('Summary') === -1);
});

t('handles a cell above the header row gracefully', () => {
  ACTIVE = { row: 1, col: 3 };
  const ctx = sandbox.getCellContext();
  assert.strictEqual(ctx.rowPairs.length, 0, 'header row contributes no row facts');
  ACTIVE = { row: 5, col: 3 };
});

t('columnLetter_ handles multi-letter columns', () => {
  assert.strictEqual(sandbox.columnLetter_(1), 'A');
  assert.strictEqual(sandbox.columnLetter_(26), 'Z');
  assert.strictEqual(sandbox.columnLetter_(27), 'AA');
  assert.strictEqual(sandbox.columnLetter_(703), 'AAA');
});

console.log('\nprompt builder');
t('continuation mode instructs the model not to repeat the prefix', () => {
  const s = sandbox.getSettings();
  s.instruction = 'British English, under 15 words.';
  const msgs = sandbox.buildMessages_(sandbox.getCellContext(), s);
  assert.strictEqual(msgs.length, 2);
  assert.ok(/Never repeat the text they already typed/.test(msgs[0].content));
  assert.ok(/strict JSON/.test(msgs[0].content));
  const u = msgs[1].content;
  assert.ok(u.includes('COLUMN HEADER: Summary'));
  assert.ok(u.includes('- Customer: Vetrix'));
  assert.ok(u.includes('Invoice 4471 was charged twice in March.'));
  assert.ok(u.includes('British English, under 15 words.'));
  assert.ok(u.includes('Customer reported that the'));
});

t('empty cell switches to fill mode', () => {
  GRID[4][2] = '';
  const msgs = sandbox.buildMessages_(sandbox.getCellContext(), sandbox.getSettings());
  assert.ok(/The cell is empty. Return the complete value/.test(msgs[0].content));
  assert.ok(/The cell is empty. Write its value./.test(msgs[1].content));
  GRID[4][2] = 'Customer reported that the';
});

t('context toggles actually remove sections from the prompt', () => {
  const s = sandbox.getSettings();
  s.useRow = false; s.useNeighbours = false; s.useHeader = false;
  const u = sandbox.buildMessages_(sandbox.getCellContext(), s)[1].content;
  assert.ok(!u.includes('COLUMN HEADER'));
  assert.ok(!u.includes('OTHER VALUES IN THIS ROW'));
  assert.ok(!u.includes('EXISTING ENTRIES IN THIS COLUMN'));
});

console.log('\nresponse parser');
const P = sandbox.parseCompletions_;
t('parses the contracted shape', () => {
  eq(P('{"completions":["a","b"]}'), ['a', 'b']);
});
t('parses a fenced block', () => {
  eq(P('```json\n{"completions":["a"]}\n```'), ['a']);
});
t('parses a bare array', () => {
  eq(P('["a","b"]'), ['a', 'b']);
});
t('parses a single-key object', () => {
  eq(P('{"completion":"only one"}'), ['only one']);
});
t('parses a numbered object', () => {
  eq(P('{"1":"a","2":"b"}'), ['a', 'b']);
});
t('falls back to lines and strips list markers and quotes', () => {
  eq(P('1. first\n- "second"\n\n* third'), ['first', 'second', 'third']);
});
t('dedupes case-insensitively and drops blanks', () => {
  eq(P('["Same","same","","  "]'), ['Same']);
});
t('survives null entries', () => {
  eq(P('{"completions":["a",null,"b"]}'), ['a', 'b']);
});

console.log('\ngroq client');
t('posts to the right endpoint with auth, model and json response_format', () => {
  const res = sandbox.suggest({ model: 'llama-3.1-8b-instant', temperature: 0.4 });
  assert.strictEqual(lastFetch.url, 'https://api.groq.com/openai/v1/chat/completions');
  assert.strictEqual(lastFetch.opts.headers.Authorization, 'Bearer gsk_test_key');
  assert.strictEqual(lastFetch.body.model, 'llama-3.1-8b-instant');
  eq(lastFetch.body.response_format, { type: 'json_object' });
  assert.strictEqual(lastFetch.body.stream, false);
  assert.strictEqual(res.mode, 'continue');
  assert.strictEqual(res.completions.length, 3);
  assert.strictEqual(res.completions[0], 'invoice total did not match the purchase order.');
});

t('respects numSuggestions when trimming', () => {
  const res = sandbox.suggest({ numSuggestions: 2 });
  assert.strictEqual(res.completions.length, 2);
});

t('strips an echoed prefix from the model output', () => {
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ message: { content: '{"completions":["Customer reported that the box was empty."]}' } }] }) });
  const res = sandbox.suggest({});
  assert.strictEqual(res.completions[0], ' box was empty.');
});

t('surfaces 401 as a readable message', () => {
  fetchResponse = () => ({ code: 401, text: '{"error":{"message":"Invalid API Key"}}' });
  assert.throws(() => sandbox.suggest({}), /rejected the API key/);
});
t('surfaces 429 as a readable message', () => {
  fetchResponse = () => ({ code: 429, text: '{"error":{"message":"rate limit"}}' });
  assert.throws(() => sandbox.suggest({}), /rate limit hit/);
});
t('surfaces other errors with the upstream text', () => {
  fetchResponse = () => ({ code: 400, text: '{"error":{"message":"model_decommissioned"}}' });
  assert.throws(() => sandbox.suggest({}), /model_decommissioned/);
});

console.log('\ncell writing');
fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ message: { content: '{"completions":["x"]}' } }] }) });
t('continue appends with exactly one space', () => {
  GRID[4][2] = 'Customer reported that the';
  const v = sandbox.applyCompletion('C5', 'invoice was wrong.', 'continue');
  assert.strictEqual(v, 'Customer reported that the invoice was wrong.');
});
t('continue does not double a trailing space', () => {
  GRID[4][2] = 'Customer reported that the ';
  const v = sandbox.applyCompletion('C5', 'invoice was wrong.', 'continue');
  assert.strictEqual(v, 'Customer reported that the invoice was wrong.');
});
t('continue does not space before punctuation', () => {
  GRID[4][2] = 'Refund issued';
  const v = sandbox.applyCompletion('C5', ', per policy 4.2.', 'continue');
  assert.strictEqual(v, 'Refund issued, per policy 4.2.');
});
t('continue does not double a leading space', () => {
  GRID[4][2] = 'Refund issued';
  const v = sandbox.applyCompletion('C5', ' today.', 'continue');
  assert.strictEqual(v, 'Refund issued today.');
});
t('fill replaces the whole cell', () => {
  GRID[4][2] = '';
  const v = sandbox.applyCompletion('C5', 'Brand new value.', 'fill');
  assert.strictEqual(v, 'Brand new value.');
});
t('writes are routed to the sheet the suggestion came from', () => {
  GRID[4][2] = '';
  const v = sandbox.applyCompletion('C5', 'Routed.', 'fill', 'Tickets');
  assert.strictEqual(v, 'Routed.');
  assert.throws(() => sandbox.applyCompletion('C5', 'x', 'fill', 'Deleted Sheet'), /no longer exists/);
});
t('suggest echoes the sheet name for that guard', () => {
  GRID[4][2] = 'Customer reported that the';
  assert.strictEqual(sandbox.suggest({}).sheetName, 'Tickets');
});

console.log('\nsettings');
t('round-trips and clamps to known keys', () => {
  const s = sandbox.saveSettings({ model: 'openai/gpt-oss-20b', bogus: 1, instruction: 'terse' });
  assert.strictEqual(s.model, 'openai/gpt-oss-20b');
  assert.strictEqual(s.instruction, 'terse');
  assert.strictEqual(s.bogus, undefined);
  assert.ok(Array.isArray(s.models) && s.models.length >= 4);
  assert.strictEqual(s.hasKey, true);
});
t('listModels filters non-chat models and labels context windows', () => {
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ data: [
    { id: 'openai/gpt-oss-20b', context_window: 131072 },
    { id: 'whisper-large-v3' },
    { id: 'meta-llama/llama-guard-4-12b' },
    { id: 'qwen/qwen3.6-27b', context_window: 131072 },
  ] }) });
  const m = sandbox.listModels();
  eq(m.map(x => x.id), ['openai/gpt-oss-20b', 'qwen/qwen3.6-27b']);
  assert.ok(/131k ctx/.test(m[0].label));
});

t('listModels falls back to the static list when Groq is unreachable', () => {
  fetchResponse = () => ({ code: 500, text: 'boom' });
  assert.ok(sandbox.listModels().length >= 4);
});

t('a 404 is reported as a decommissioned model, not a generic error', () => {
  fetchResponse = () => ({ code: 404, text: '{"error":{"message":"does not exist"}}' });
  assert.throws(() => sandbox.suggest({ model: 'llama-3.1-8b-instant' }), /decommissioned/);
});

t('reasoning models get a low reasoning_effort and a scaled token budget', () => {
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ message: { content: '{"completions":["a","b","c"]}' } }] }) });
  sandbox.suggest({ model: 'openai/gpt-oss-20b', numSuggestions: 3, maxTokens: 500 });
  assert.strictEqual(lastFetch.body.reasoning_effort, 'low');
  assert.strictEqual(lastFetch.body.max_tokens, 800, '500 + 2 extra suggestions * 150');
  sandbox.suggest({ model: 'moonshotai/kimi-k2-instruct', numSuggestions: 1, maxTokens: 500 });
  assert.strictEqual(lastFetch.body.reasoning_effort, undefined);
  assert.strictEqual(lastFetch.body.max_tokens, 500);
});

t('a JSON-validation 400 retries once in plain-text mode', () => {
  let calls = 0;
  fetchResponse = () => {
    calls++;
    if (calls === 1) return { code: 400, text: '{"error":{"message":"Failed to validate JSON. See failed_generation"}}' };
    return { code: 200, text: JSON.stringify({ choices: [{ message: { content: '{"completions":["recovered"]}' } }] }) };
  };
  const res = sandbox.suggest({ model: 'openai/gpt-oss-20b' });
  assert.strictEqual(calls, 2, 'retried exactly once');
  assert.strictEqual(lastFetch.body.response_format, undefined, 'json mode dropped on retry');
  assert.ok(/raw JSON object and nothing else/.test(lastFetch.body.messages[0].content));
  assert.strictEqual(res.completions[0], 'recovered');
});

t('a non-JSON 400 is not retried', () => {
  let calls = 0;
  fetchResponse = () => { calls++; return { code: 400, text: '{"error":{"message":"context_length_exceeded"}}' }; };
  assert.throws(() => sandbox.suggest({}), /context_length_exceeded/);
  assert.strictEqual(calls, 1);
});

t('salvages suggestions from a reply truncated mid-array', () => {
  eq(sandbox.parseCompletions_('{"completions":["first one","second one","third is cut o'),
     ['first one', 'second one']);
});

t('salvage keeps escaped quotes intact', () => {
  eq(sandbox.parseCompletions_('{"completions":["he said \\"hi\\" loudly","tail'),
     ['he said "hi" loudly']);
});

t('explains an empty reply caused by hitting the token ceiling', () => {
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ finish_reason: 'length', message: { content: '' } }] }) });
  assert.throws(() => sandbox.suggest({}), /hit its token limit/);
});

console.log('\nproject context');
t('the brief leads the prompt and is labelled as background fact', () => {
  const st = sandbox.getSettings();
  st.projectContext = 'Flownix is a gym management app. One row is one QA defect.';
  const u = sandbox.buildMessages_(sandbox.getCellContext(), st)[1].content;
  assert.ok(u.indexOf('ABOUT THIS PRODUCT AND SHEET') === 0, 'appears before everything else');
  assert.ok(u.includes('Flownix is a gym management app'));
  assert.ok(u.indexOf('ABOUT THIS PRODUCT') < u.indexOf('COLUMN HEADER'));
});

t('an empty brief adds no block at all', () => {
  const u = sandbox.buildMessages_(sandbox.getCellContext(), sandbox.getSettings())[1].content;
  assert.ok(!u.includes('ABOUT THIS PRODUCT'));
});

t('sheetMap_ lists every tab with its headers and row count', () => {
  const map = sandbox.sheetMap_();
  eq(map, [{ name: 'Tickets', rows: GRID.length - 1, headers: ['Customer', 'Issue', 'Summary'] }]);
});

t('the workbook structure block is toggleable', () => {
  const st = sandbox.getSettings();
  const ctx = sandbox.getCellContext();
  ctx.sheetMap = sandbox.sheetMap_();
  st.useSheetMap = true;
  assert.ok(sandbox.buildMessages_(ctx, st)[1].content.includes('WORKBOOK STRUCTURE'));
  st.useSheetMap = false;
  assert.ok(!sandbox.buildMessages_(ctx, st)[1].content.includes('WORKBOOK STRUCTURE'));
});

t('the brief is capped so it cannot blow the 9KB property limit', () => {
  const s2 = sandbox.saveSettings({ projectContext: 'x'.repeat(9000) });
  assert.strictEqual(s2.projectContext.length, 4000);
  sandbox.saveSettings({ projectContext: '' });
});

t('draftProjectContext asks for prose, not JSON, and forbids invention', () => {
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ message: { content: 'Tracks QA defects for a gym app.' } }] }) });
  const out = sandbox.draftProjectContext();
  assert.strictEqual(out, 'Tracks QA defects for a gym app.');
  assert.strictEqual(lastFetch.body.response_format, undefined, 'prose call, no JSON mode');
  assert.ok(/Never invent a company name/.test(lastFetch.body.messages[0].content));
  assert.ok(lastFetch.body.messages[1].content.includes('Customer | Issue | Summary'));
  assert.ok(lastFetch.body.messages[1].content.includes('Invoice 4471'), 'includes sample rows');
});

console.log('\nselection');
t('reports rows, cols, totals and per-cell fill state', () => {
  SELECTION = { row: 2, col: 2, rows: 3, cols: 2 };   // B2:C4
  const sel = sandbox.getCellContext().selection;
  assert.strictEqual(sel.a1, 'B2:C4');
  assert.strictEqual(sel.rows, 3);
  assert.strictEqual(sel.cols, 2);
  assert.strictEqual(sel.total, 6);
  assert.strictEqual(sel.cells.length, 6);
  eq(sel.cells.map(c => c.a1), ['B2', 'C2', 'B3', 'C3', 'B4', 'C4']);
  assert.ok(sel.cells.every(c => c.filled), 'B2:C4 is fully populated in the fixture');
  SELECTION = null;
});

t('counts empty cells so the sidebar can offer skip-filled', () => {
  GRID[4][2] = '';                                    // blank out C5
  SELECTION = { row: 4, col: 3, rows: 2, cols: 1 };    // C4:C5
  const sel = sandbox.getCellContext().selection;
  assert.strictEqual(sel.empty, 1);
  eq(sel.cells.map(c => c.filled), [true, false]);
  SELECTION = null;
  GRID[4][2] = 'Customer reported that the';
});

t('clamps a whole-column selection to the used range', () => {
  SELECTION = { row: 1, col: 3, rows: 1000, cols: 1 };
  const sel = sandbox.getCellContext().selection;
  assert.strictEqual(sel.total, GRID.length, 'clamped to rows that exist');
  assert.strictEqual(sel.a1, 'C1:C' + GRID.length);
  SELECTION = null;
});

t('a single-cell selection hides the panel', () => {
  assert.strictEqual(sandbox.getCellContext().selection.total, 1);
});

console.log('\nbatch');
t('completeCell fills a named cell without moving the active cell', () => {
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ message: { content: '{"completions":["Filled by batch."]}' } }] }) });
  GRID[5][2] = '';
  const before = { ...ACTIVE };
  const res = sandbox.completeCell('Tickets', 'C6', {}, false);
  assert.strictEqual(res.status, 'written');
  assert.strictEqual(GRID[5][2], 'Filled by batch.');
  eq(ACTIVE, before, 'active cell untouched');
});

t('completeCell honours skipFilled', () => {
  GRID[5][2] = 'Already here.';
  const res = sandbox.completeCell('Tickets', 'C6', {}, true);
  assert.strictEqual(res.status, 'skipped');
  assert.strictEqual(GRID[5][2], 'Already here.');
});

t('completeCell continues a partly typed cell rather than replacing it', () => {
  GRID[5][2] = 'The pantry view';
  fetchResponse = () => ({ code: 200, text: JSON.stringify({ choices: [{ message: { content: '{"completions":["drops items on save."]}' } }] }) });
  const res = sandbox.completeCell('Tickets', 'C6', {}, false);
  assert.strictEqual(res.status, 'written');
  assert.strictEqual(GRID[5][2], 'The pantry view drops items on save.');
});

t('completeCell reports a missing sheet instead of writing elsewhere', () => {
  assert.throws(() => sandbox.completeCell('Gone', 'C6', {}, false), /no longer exists/);
});

t('missing key raises a clear error', () => {
  sandbox.props_().deleteProperty('GROQ_API_KEY');
  assert.throws(() => sandbox.suggest({}), /No Groq API key set/);
});

console.log('\n' + pass + ' checks passed' + (process.exitCode ? ' — with failures above\n' : '\n'));
