# Preset — PM writing bug tickets for developers

Paste the block below into **Settings → Tone / style instructions** in the sidebar.
It is sent as the highest-priority instruction in every request.

```text
I am a product manager writing bug tickets that developers will pick up and fix. Each row is one bug.

Write so a developer can start work without asking me a follow-up question:
- Lead with the observable behaviour. Never speculate about the cause, the file, or the fix.
- Name the exact screen, module or flow the bug lives in, using the product's own wording.
- State what happens now, then what should happen instead, in that order.
- Present tense, active voice, factual. No hedging ("seems", "maybe", "I think"), no apologies, no pleasantries.
- Two sentences maximum, unless the surrounding entries in this column are longer — then match them.
- If the row implies reproduction steps, keep them numbered and terse.
- Quote UI labels exactly as they appear; never invent a feature, screen or setting name.
- Never invent ticket IDs, version numbers, dates, customer names, severity or priority labels. If a detail is not in this row, leave it out.
- Do not restate the column header or repeat text I have already typed.
```

## Why each rule is there

| Rule | What it prevents |
|---|---|
| Observable behaviour, no speculation | LLMs guess at root causes confidently and wrongly, sending devs down dead ends |
| Name the screen/flow | "The button is broken" tickets that bounce straight back to you |
| Now vs. expected, in that order | Devs scanning a board need the delta first |
| Match neighbouring length | Keeps a column visually consistent; your existing rows set the standard |
| Never invent IDs/versions/severity | The highest-risk hallucination in a bug tracker — invented metadata looks authoritative |
| Don't restate the header | Stops "Fix: The fix is to fix…" padding |

## Variants

**Terser, for a board with small cards**

```text
Same rules, but one sentence, under 20 words, starting with the broken noun. Example: "Pantry view drops line items when an order is saved with more than one item."
```

**With acceptance criteria**, if your column holds the whole ticket

```text
After the behaviour description, add a line "Done when:" followed by one testable condition. No more than one.
```

**Reproduction-steps column**

```text
Output only numbered steps, one action per line, starting from a known state ("From the walk-in enquiry flow…"). No preamble, no expected result — that lives in another column.
```
